package ru.team.mutegui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;

public class MuteScreen extends Screen {
    private static final String[] TIMES = {"30m", "60m", "120m", "180m", "6h", "12h", "24h", "72h"};

    private final String target;
    private String reason = null;
    private String time = null;

    private final List<ButtonWidget> reasonButtons = new ArrayList<>();
    private final List<String> reasonValues = new ArrayList<>();
    private final List<ButtonWidget> timeButtons = new ArrayList<>();
    private ButtonWidget confirm;

    public MuteScreen(String target) {
        super(Text.literal("Мут игрока " + target));
        this.target = target;
    }

    @Override
    protected void init() {
        reasonButtons.clear();
        reasonValues.clear();
        timeButtons.clear();

        int bw = 50, bh = 20, gap = 4;

        // Причины 2.2 ... 2.20 (5 колонок)
        int cols = 5;
        int gridW = cols * bw + (cols - 1) * gap;
        int x0 = width / 2 - gridW / 2;
        int y0 = 40;
        for (int i = 0; i < 19; i++) {
            String value = "2." + (i + 2);
            int x = x0 + (i % cols) * (bw + gap);
            int y = y0 + (i / cols) * (bh + gap);
            ButtonWidget b = ButtonWidget.builder(Text.literal(value), btn -> {
                reason = value;
                refresh();
            }).dimensions(x, y, bw, bh).build();
            reasonButtons.add(b);
            reasonValues.add(value);
            addDrawableChild(b);
        }

        // Время (4 колонки)
        int tcols = 4;
        int tGridW = tcols * bw + (tcols - 1) * gap;
        int tx0 = width / 2 - tGridW / 2;
        int ty0 = 158;
        for (int i = 0; i < TIMES.length; i++) {
            String value = TIMES[i];
            int x = tx0 + (i % tcols) * (bw + gap);
            int y = ty0 + (i / tcols) * (bh + gap);
            ButtonWidget b = ButtonWidget.builder(Text.literal(value), btn -> {
                time = value;
                refresh();
            }).dimensions(x, y, bw, bh).build();
            timeButtons.add(b);
            addDrawableChild(b);
        }

        confirm = ButtonWidget.builder(Text.literal("Подтвердить"), btn -> doMute())
                .dimensions(width / 2 - 75, 216, 150, 20).build();
        addDrawableChild(confirm);

        refresh();
    }

    private void refresh() {
        for (int i = 0; i < reasonButtons.size(); i++) {
            String v = reasonValues.get(i);
            boolean sel = v.equals(reason);
            reasonButtons.get(i).setMessage(sel ? Text.literal(v).formatted(Formatting.GREEN, Formatting.BOLD) : Text.literal(v));
        }
        for (int i = 0; i < timeButtons.size(); i++) {
            boolean sel = TIMES[i].equals(time);
            timeButtons.get(i).setMessage(sel ? Text.literal(TIMES[i]).formatted(Formatting.GREEN, Formatting.BOLD) : Text.literal(TIMES[i]));
        }
        confirm.active = reason != null && time != null;
    }

    private void doMute() {
        if (reason == null || time == null) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        String cmd = MuteModClient.CONFIG.muteCommand
                .replace("{player}", target)
                .replace("{time}", time)
                .replace("{reason}", reason);
        if (cmd.startsWith("/")) cmd = cmd.substring(1);
        mc.player.networkHandler.sendChatCommand(cmd);
        close();
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 14, 0xFF5555);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Причина"), width / 2, 28, 0xFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Время мута"), width / 2, 146, 0xFFFFFF);
    }
}
