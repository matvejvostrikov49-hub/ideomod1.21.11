package ru.team.mutegui;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class MuteModClient implements ClientModInitializer {
    public static MuteConfig CONFIG;
    private static KeyBinding openKey;

    @Override
    public void onInitializeClient() {
        CONFIG = MuteConfig.load();

        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.mutegui.open",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_M,
                "category.mutegui"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.wasPressed()) {
                if (client.player != null && client.currentScreen == null) {
                    client.setScreen(new MuteTargetScreen());
                }
            }
        });

        // Команда на случай, если нужно открыть меню для конкретного ника напрямую
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("mutegui_open")
                        .then(ClientCommandManager.argument("player", StringArgumentType.word())
                                .executes(ctx -> {
                                    String player = StringArgumentType.getString(ctx, "player");
                                    MinecraftClient mc = MinecraftClient.getInstance();
                                    mc.execute(() -> {
                                        if (mc.player == null) return;
                                        mc.player.networkHandler.sendChatCommand(CONFIG.openCommand);
                                        mc.setScreen(new MuteScreen(player));
                                    });
                                    return 1;
                                }))));
    }
}
